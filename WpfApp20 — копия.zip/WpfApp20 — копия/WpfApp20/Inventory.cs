﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using WpfApp20;

namespace WpfApp20
{
    // Сервис для управления инвентарем
    public class InventoryService
    {
        private List<Product> prod;
        private readonly string dFile = "inventory.json";

        public InventoryService()
        {
            LoadData();
        }

        //Загрузка данных из файла
        private void LoadData()
        {
            try
            {
                if (File.Exists(dFile))
                {
                    string jsonString = File.ReadAllText(dFile);
                    prod = JsonSerializer.Deserialize<List<Product>>(jsonString) ?? new List<Product>();
                }
                else
                {
                    prod = new List<Product>();
                }
            }
            catch (Exception)
            {
               prod = new List<Product>();
            }
        }

        // Сохранение данных в файл
        private void SaveData()
        {
            string jsonString = JsonSerializer.Serialize(prod);
            File.WriteAllText(dFile, jsonString);
        }

        // Добавление нового товара
        public void AddProduct(Product product)
        {
            if (product == null)
                throw new ArgumentNullException(nameof(product));

            if (string.IsNullOrWhiteSpace(product.Name))
                throw new ArgumentException("Название товара пустое");

            if (product.Quantity < 0)
                throw new ArgumentException("Количество товара отрицательное");

            if (product.Price < 0)
                throw new ArgumentException("Цена товара отрицательное");

            product.Id = prod.Any() ? prod.Max(p => p.Id) + 1 : 1;
            prod.Add(product);
            SaveData();
        }

        // Обновление существующего товара
        public void UpdateProduct(Product product)
        {
            if (product == null)
                throw new ArgumentNullException(nameof(product));

            var existingProduct = prod.FirstOrDefault(p => p.Id == product.Id);
            if (existingProduct == null)
                throw new ArgumentException("Товара нет");

            existingProduct.Name = product.Name;
            existingProduct.Description = product.Description;
            existingProduct.Quantity = product.Quantity;
            existingProduct.Price = product.Price;
            existingProduct.Category = product.Category;
            existingProduct.LastUpdated = DateTime.Now;

            SaveData();
        }

        // Удаление товара
        public void DeleteProduct(int id)
        {
            var product = prod.FirstOrDefault(p => p.Id == id);
            if (product != null)
            {
                prod.Remove(product);
                SaveData();
            }
        }

        // Получение всех товаров
        public List<Product> GetAllProducts()
        {
            return prod.ToList();
        }

        // Поиск товаров по названию
        public List<Product> SearchProducts(string searchTerm)
        {
            return prod
                .Where(p => p.Name.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                           p.Description.Contains(searchTerm, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }
    }
}