﻿using System;
using System.Windows;
using System.Windows.Controls;
using WpfApp20;


namespace WpfApp20
{
    public partial class MainWindow : Window
    {
        private readonly InventoryService inventServ;
        private Product selectProd;

        public MainWindow()
        {
            InitializeComponent();
            inventServ = new InventoryService();
            RefrProductsList();
        }

        // Обновление списка товаров
        private void RefrProductsList()
        {
            ProdGrid.ItemsSource = inventServ.GetAllProducts();
        }

        // Очистка формы
        private void ClearForm()
        {
            NameTB.Text = "";
            DescriptTB.Text = "";
            QuantTB.Text = "";
            PriceTB.Text = "";
            CategoryTB.Text = "";
            selectProd = null;
        }

        // Проверка валидности введенных данных
        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(NameTB.Text))
            {
                MessageBox.Show("Введите название товара", "Ошибка", MessageBoxButton.OK);
                return false;
            }

            if (!int.TryParse(QuantTB.Text, out int quantity) || quantity < 0)
            {
                MessageBox.Show("Введите количество товара", "Ошибка", MessageBoxButton.OK);
                return false;
            }

            if (!decimal.TryParse(PriceTB.Text, out decimal price) || price < 0)
            {
                MessageBox.Show("Введите цену товара", "Ошибка", MessageBoxButton.OK);
                return false;
            }

            return true;
        }

        // Обработчик события добавления товара
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!ValidateInput())
                    return;

                var product = new Product
                {
                    Name = NameTB.Text,
                    Description = DescriptTB.Text,
                    Quantity = int.Parse(QuantTB.Text),
                    Price = decimal.Parse(PriceTB.Text),
                    Category = CategoryTB.Text
                };

                inventServ.AddProduct(product);
                RefrProductsList();
                ClearForm();
                MessageBox.Show("Товар успешно добавлен", "Успех", MessageBoxButton.OK);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении товара: {ex.Message}", "Ошибка", MessageBoxButton.OK);
            }
        }

        // Обработчик события сохранения изменений товара
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (selectProd == null)
                {
                    MessageBox.Show("Выберите товар для редактирования", "Ошибка", MessageBoxButton.OK);
                    return;
                }

                if (!ValidateInput())
                    return;

                selectProd.Name = NameTB.Text;
                selectProd.Description = DescriptTB.Text;
                selectProd.Quantity = int.Parse(QuantTB.Text);
                selectProd.Price = decimal.Parse(PriceTB.Text);
                selectProd.Category = CategoryTB.Text;

                inventServ.UpdateProduct(selectProd);
                RefrProductsList();
                ClearForm();
                MessageBox.Show("Товар успешно обновлен", "Успех", MessageBoxButton.OK);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении товара: {ex.Message}", "Ошибка", MessageBoxButton.OK);
            }
        }

        // Обработчик события удаления товара
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (selectProd == null)
            {
                MessageBox.Show("Выберите товар для удаления", "Ошибка", MessageBoxButton.OK);
                return;
            }

            var result = MessageBox.Show("Вы уверены, что хотите удалить этот товар?", "Подтверждение", 
                MessageBoxButton.YesNo);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    inventServ.DeleteProduct(selectProd.Id);
                    RefrProductsList();
                    ClearForm();
                    MessageBox.Show("Товар успешно удален", "Успех", MessageBoxButton.OK);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении товара: {ex.Message}", "Ошибка", MessageBoxButton.OK);
                }
            }
        }

        // Обработчик события выбора товара в списке
        private void ProdGridSC(object sender, SelectionChangedEventArgs e)
        {
            selectProd = ProdGrid.SelectedItem as Product;
            if (selectProd != null)
            {
                NameTB.Text = selectProd.Name;
                DescriptTB.Text = selectProd.Description;
                QuantTB.Text = selectProd.Quantity.ToString();
                PriceTB.Text = selectProd.Price.ToString();
                CategoryTB.Text = selectProd.Category;
            }
        }

        // Обработчик события поиска товаров
        private void SearchBoxTC(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(SearchBox.Text))
            {
                RefrProductsList();
            }
            else
            {
                ProdGrid.ItemsSource = inventServ.SearchProducts(SearchBox.Text);
            }
        }

        // Обработчик события обновления списка товаров
        private void RefrButton_Click(object sender, RoutedEventArgs e)
        {
            RefrProductsList();
        }
    }
}