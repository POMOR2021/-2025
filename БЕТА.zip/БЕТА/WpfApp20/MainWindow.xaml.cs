﻿using System;
using System.Windows;
using System.Windows.Controls;
using WpfApp20;


namespace WpfApp20
{
    public partial class MainWindow : Window
    {
        private readonly InventoryService inventServ;
        private Product selectProd;

        public MainWindow()
        {
            InitializeComponent();
            inventServ = new InventoryService();
            InitializeInventoryLists();
            RefrProductsList();
        }

        private void InitializeInventoryLists()
        {
            InventoryListComboBox.ItemsSource = inventServ.GetAvailableLists();
            InventoryListComboBox.SelectedIndex = 0;
        }

        // Обновление списка товаров
        private void RefrProductsList()
        {
            ProdGrid.ItemsSource = inventServ.GetAllProducts();
        }

        // Очистка формы
        private void ClearForm()
        {
            NameTB.Text = "";
            DescriptTB.Text = "";
            QuantTB.Text = "";
            PriceTB.Text = "";
            CategoryTB.Text = "";
            selectProd = null;
        }

        // Проверка введенных данных
        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(NameTB.Text))
            {
                MessageBox.Show("Введите название товара", "Ошибка", MessageBoxButton.OK);
                return false;
            }

            if (!int.TryParse(QuantTB.Text, out int quantity) || quantity < 0)
            {
                MessageBox.Show("Введите количество товара", "Ошибка", MessageBoxButton.OK);
                return false;
            }

            if (!decimal.TryParse(PriceTB.Text, out decimal price) || price < 0)
            {
                MessageBox.Show("Введите цену товара", "Ошибка", MessageBoxButton.OK);
                return false;
            }

            return true;
        }

        //Обработчик добавления товара
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!ValidateInput())
                    return;

                var product = new Product
                {
                    Name = NameTB.Text,
                    Description = DescriptTB.Text,
                    Quantity = int.Parse(QuantTB.Text),
                    Price = decimal.Parse(PriceTB.Text),
                    Category = CategoryTB.Text
                };

                inventServ.AddProduct(product);
                RefrProductsList();
                ClearForm();
                MessageBox.Show("Товар успешно добавлен", "Успех", MessageBoxButton.OK);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении товара: {ex.Message}", "Ошибка", MessageBoxButton.OK);
            }
        }

        //Обработчик сохранения изменений товара
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (selectProd == null)
                {
                    MessageBox.Show("Выберите товар для редактирования", "Ошибка", MessageBoxButton.OK);
                    return;
                }

                if (!ValidateInput())
                    return;

                selectProd.Name = NameTB.Text;
                selectProd.Description = DescriptTB.Text;
                selectProd.Quantity = int.Parse(QuantTB.Text);
                selectProd.Price = decimal.Parse(PriceTB.Text);
                selectProd.Category = CategoryTB.Text;

                inventServ.UpdateProduct(selectProd);
                RefrProductsList();
                ClearForm();
                MessageBox.Show("Товар успешно обновлен", "Успех", MessageBoxButton.OK);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении товара: {ex.Message}", "Ошибка", MessageBoxButton.OK);
            }
        }

        //Обработчик удаления товара
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (selectProd == null)
            {
                MessageBox.Show("Выберите товар для удаления", "Ошибка", MessageBoxButton.OK);
                return;
            }

            var result = MessageBox.Show("Вы уверены, что хотите удалить этот товар?", "Подтверждение", 
                MessageBoxButton.YesNo);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    inventServ.DeleteProduct(selectProd.Id);
                    RefrProductsList();
                    ClearForm();
                    MessageBox.Show("Товар успешно удален", "Успех", MessageBoxButton.OK);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении товара: {ex.Message}", "Ошибка", MessageBoxButton.OK);
                }
            }
        }

        //Обработчик выбора товара в списке
        private void ProdGridSC(object sender, SelectionChangedEventArgs e)
        {
            selectProd = ProdGrid.SelectedItem as Product;
            if (selectProd != null)
            {
                NameTB.Text = selectProd.Name;
                DescriptTB.Text = selectProd.Description;
                QuantTB.Text = selectProd.Quantity.ToString();
                PriceTB.Text = selectProd.Price.ToString();
                CategoryTB.Text = selectProd.Category;
            }
        }

        //Обработчик поиска товаров
        private void SearchBoxTC(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(SearchBox.Text))
            {
                RefrProductsList();
            }
            else
            {
                ProdGrid.ItemsSource = inventServ.SearchProducts(SearchBox.Text);
            }
        }

        //Обработчик обновления списка товаров
        private void RefrButton_Click(object sender, RoutedEventArgs e)
        {
            RefrProductsList();
        }

        //Обработчик выбора списка инвентаря
        private void InventoryListComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (InventoryListComboBox.SelectedItem is string selectedList)
            {
                try
                {
                    inventServ.SwitchToList(selectedList);
                    RefrProductsList();
                    ClearForm();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при переключении списка: {ex.Message}", "Ошибка", MessageBoxButton.OK);
                }
            }
        }

        // Обработчик создания нового списка
        private void NewListButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new InputDialog("Новый список инвентаря", "Введите название нового списка:");
            if (dialog.ShowDialog() == true)
            {
                try
                {
                    inventServ.CreateNewList(dialog.ResponseText);
                    InitializeInventoryLists();
                    RefrProductsList();
                    ClearForm();
                    MessageBox.Show("Новый список успешно создан", "Успех", MessageBoxButton.OK);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при создании списка: {ex.Message}", "Ошибка", MessageBoxButton.OK);
                }
            }
        }
    }
}