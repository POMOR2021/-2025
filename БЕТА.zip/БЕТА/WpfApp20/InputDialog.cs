using System.Windows;
using System.Windows.Controls;

namespace WpfApp20
{
    public class InputDialog : Window
    {
        private TextBox TB;
        public string ResponseText { get; private set; }

        public InputDialog(string title, string question)
        {
            Title = title;
            Width = 300;
            Height = 150;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;

            var grid = new Grid { Margin = new Thickness(10) };
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            var label = new Label { Content = question };
            Grid.SetRow(label, 0);
            grid.Children.Add(label);

            TB = new TextBox { Margin = new Thickness(0, 10, 0, 0) };
            Grid.SetRow(TB, 1);
            grid.Children.Add(TB);

            var buttonPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0, 10, 0, 0)
            };

            var okButton = new Button { Content = "OK", Width = 70, Margin = new Thickness(0, 0, 10, 0) };
            okButton.Click += (s, e) =>
            {
                ResponseText = TB.Text;
                DialogResult = true;
                Close();
            };

            var cancelButton = new Button { Content = "Отмена", Width = 70 };
            cancelButton.Click += (s, e) =>
            {
                DialogResult = false;
                Close();
            };

            buttonPanel.Children.Add(okButton);
            buttonPanel.Children.Add(cancelButton);

            Grid.SetRow(buttonPanel, 2);
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.Children.Add(buttonPanel);

            Content = grid;
        }
    }
} 